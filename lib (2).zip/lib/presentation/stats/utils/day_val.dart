class DayVal {
  final DateTime day;
  final double v;
  const DayVal(this.day, this.v);
}
