import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/stats_models.dart';
import '../models/stats_period.dart';
import '../utils/stats_data_provider.dart';
import '../utils/op_day.dart';
import 'stats_state.dart';

class StatsCubit extends Cubit<StatsState> {
  StatsCubit()
      : super(
          StatsState(
            month: defaultStatsMonth(),
            period: defaultStatsPeriod(),
            overview: null,
            preview: null,
            previousMonths: const [],
            loading: true,
            previewLoading: true,
            previousLoading: false,
            error: null,
            previewError: null,
            previousError: null,
          ),
        ) {
    _loadMonth(state.month, state.period);
  }

  List<Map<String, dynamic>> _rawMonth = const [];
  List<Map<String, dynamic>> _rawExpenses = const [];
  final Map<String, List<Map<String, dynamic>>> _rawSalesCache = {};
  final Map<String, List<Map<String, dynamic>>> _rawExpensesCache = {};
  final Map<String, Map<String, dynamic>> _rawMonthById = {};
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _todaySalesSub;
  Timer? _realtimeDebounce;
  DateTime? _currentMonthStartUtc;
  DateTime? _currentMonthEndUtc;

  Future<void> refresh() => _loadMonth(
        state.month,
        state.period,
        force: true,
      );

  Future<void> setMonth(DateTime month) =>
      _loadMonth(DateTime(month.year, month.month, 1), state.period);

  Future<void> setPeriod(StatsPeriod period) async {
    emit(state.copyWith(period: period, loading: true, error: null));
    await _computeOverview(period, state.month);
  }

  Future<void> _loadMonth(
    DateTime month,
    StatsPeriod period, {
    bool force = false,
  }) async {
    emit(
      state.copyWith(
        month: month,
        period: period,
        loading: true,
        previewLoading: true,
        previousMonths: const [],
        previousLoading: false,
        previousError: null,
        error: null,
        previewError: null,
      ),
    );
    try {
      final now = DateTime.now();
      final isCurrentMonth = month.year == now.year && month.month == now.month;
      final useCache = !force;
      final key = _cacheKey(month);
      List<Map<String, dynamic>> rawSales;
      if (useCache &&
          _rawSalesCache.containsKey(key) &&
          _rawExpensesCache.containsKey(key)) {
        rawSales = _rawSalesCache[key] ?? const [];
        _rawExpenses = _rawExpensesCache[key] ?? const [];
      } else {
        rawSales = await fetchSalesRawForMonth(month, cacheFirst: useCache);
        final fullRange = statsComputeRange(month, StatsPeriod.fullMonth);
        _rawExpenses = await fetchStatsExpenses(
          startUtc: fullRange.startUtc,
          endUtc: fullRange.endUtc,
          cacheFirst: useCache,
        );
        _rawSalesCache[key] = rawSales;
        _rawExpensesCache[key] = _rawExpenses;
      }
      _rawMonth = prepareStatsData(rawSales);
      _rebuildRawMonthIndex(rawSales);
      final fullRange = statsComputeRange(month, StatsPeriod.fullMonth);
      _currentMonthStartUtc = fullRange.startUtc;
      _currentMonthEndUtc = fullRange.endUtc;
      final preview = _buildThirdsPreview(_rawMonth, month);
      emit(
        state.copyWith(
          preview: preview,
          previewLoading: false,
          previewError: null,
        ),
      );
      _startTodaySalesListener(month, isCurrentMonth);
      await _computeOverview(period, month);
    } catch (e) {
      emit(
        state.copyWith(
          loading: false,
          previewLoading: false,
          error: e,
          previewError: e,
          previousLoading: false,
          previousError: e,
        ),
      );
    }
  }

  Future<void> _computeOverview(StatsPeriod period, DateTime month) async {
    try {
      final range = statsComputeRange(month, period);
      final data = filterStatsSales(
        _rawMonth,
        startUtc: range.startUtc,
        endUtc: range.endUtc,
      );
      final expenses = filterStatsExpenses(
        _rawExpenses,
        startUtc: range.startUtc,
        endUtc: range.endUtc,
      );
      final overview = StatsOverview(
        kpis: buildKpis(
          data,
          expenses,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        drinks: buildDrinksRows(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        beans: buildBeansRows(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        turkish: buildTurkishRows(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        extras: buildExtrasRows(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        trends: buildTrends(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
        highlights: buildHighlights(
          data,
          startUtc: range.startUtc,
          endUtc: range.endUtc,
        ),
      );
      emit(state.copyWith(overview: overview, loading: false, error: null));
    } catch (e) {
      emit(state.copyWith(loading: false, error: e));
    }
  }

  ThirdsPreview _buildThirdsPreview(
    List<Map<String, dynamic>> rawMonth,
    DateTime month,
  ) {
    Kpis kpisForRange(DateTime start, DateTime end) {
      return buildKpis(rawMonth, const [], startUtc: start, endUtc: end);
    }

    final r1 = statsComputeRange(month, StatsPeriod.firstThird);
    final r2 = statsComputeRange(month, StatsPeriod.secondThird);
    final r3 = statsComputeRange(month, StatsPeriod.thirdThird);
    final rm = statsComputeRange(month, StatsPeriod.fullMonth);

    return ThirdsPreview(
      firstThird: kpisForRange(r1.startUtc, r1.endUtc),
      secondThird: kpisForRange(r2.startUtc, r2.endUtc),
      thirdThird: kpisForRange(r3.startUtc, r3.endUtc),
      month: kpisForRange(rm.startUtc, rm.endUtc),
    );
  }

  String _cacheKey(DateTime month) =>
      '${month.year.toString().padLeft(4, '0')}-${month.month.toString().padLeft(2, '0')}';

  void _rebuildRawMonthIndex(List<Map<String, dynamic>> rawSales) {
    _rawMonthById.clear();
    for (var i = 0; i < rawSales.length; i++) {
      final sale = rawSales[i];
      var id = _saleIdFromRaw(sale);
      if (id.isEmpty) id = 'raw_$i';
      final normalized = Map<String, dynamic>.from(sale)..['id'] = id;
      _rawMonthById[id] = normalized;
    }
  }

  String _saleIdFromRaw(Map<String, dynamic> sale) {
    final id = (sale['id'] ?? sale['sale_id'] ?? sale['invoice_id'] ?? '')
        .toString()
        .trim();
    return id;
  }

  void _startTodaySalesListener(DateTime month, bool isCurrentMonth) {
    _todaySalesSub?.cancel();
    if (!isCurrentMonth) return;

    final now = DateTime.now();
    final startLocal = opStartLocal(now);
    final endLocal = opEndLocal(now);

    _todaySalesSub = FirebaseFirestore.instance
        .collection('sales')
        .where(
          'created_at',
          isGreaterThanOrEqualTo: Timestamp.fromDate(startLocal.toUtc()),
        )
        .where('created_at', isLessThan: Timestamp.fromDate(endLocal.toUtc()))
        .snapshots()
        .listen(_handleTodaySalesSnapshot);
  }

  void _handleTodaySalesSnapshot(
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) {
    var changed = false;
    for (final change in snapshot.docChanges) {
      final id = change.doc.id;
      if (change.type == DocumentChangeType.removed) {
        if (_rawMonthById.remove(id) != null) {
          changed = true;
        }
        continue;
      }
      final data = change.doc.data();
      if (data == null) continue;
      final normalized = Map<String, dynamic>.from(data)..['id'] = id;
      if (!_isInCurrentMonth(normalized)) {
        if (_rawMonthById.remove(id) != null) changed = true;
        continue;
      }
      _rawMonthById[id] = normalized;
      changed = true;
    }
    if (changed) _scheduleRealtimeRebuild();
  }

  bool _isInCurrentMonth(Map<String, dynamic> sale) {
    final start = _currentMonthStartUtc;
    final end = _currentMonthEndUtc;
    if (start == null || end == null) return true;
    final created = _asUtc(sale['created_at']);
    if (created == null) return false;
    return !created.isBefore(start) && created.isBefore(end);
  }

  DateTime? _asUtc(dynamic v) {
    if (v == null) return null;
    if (v is DateTime) return v.toUtc();
    if (v is Timestamp) return v.toDate().toUtc();
    if (v is num) {
      final raw = v.toInt();
      final ms = raw < 10000000000 ? raw * 1000 : raw;
      return DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true);
    }
    if (v is String) {
      final parsed = DateTime.tryParse(v);
      return parsed?.toUtc();
    }
    return null;
  }

  void _scheduleRealtimeRebuild() {
    _realtimeDebounce?.cancel();
    _realtimeDebounce = Timer(
      const Duration(milliseconds: 300),
      _rebuildFromRealtime,
    );
  }

  void _rebuildFromRealtime() {
    if (isClosed) return;
    final rawSales = _rawMonthById.values.toList();
    _rawMonth = prepareStatsData(rawSales);
    _rawSalesCache[_cacheKey(state.month)] = rawSales;
    final preview = _buildThirdsPreview(_rawMonth, state.month);
    emit(
      state.copyWith(
        preview: preview,
        previewLoading: false,
        previewError: null,
      ),
    );
    unawaited(_computeOverview(state.period, state.month));
  }

  @override
  Future<void> close() {
    _todaySalesSub?.cancel();
    _realtimeDebounce?.cancel();
    return super.close();
  }
}
