class RecipePriceCost {
  final double pricePerKg;
  final double costPerKg;

  const RecipePriceCost({
    required this.pricePerKg,
    required this.costPerKg,
  });
}
