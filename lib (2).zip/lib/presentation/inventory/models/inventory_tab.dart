enum InventoryTab { all, singles, blends, extras, drinks }
