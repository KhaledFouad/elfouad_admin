import 'dart:async' show unawaited, StreamSubscription;
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:elfouad_admin/services/archive/monthly_archive_stats.dart';
import '../models/archive_month.dart';
import 'archive_months_state.dart';

class ArchiveMonthsCubit extends Cubit<ArchiveMonthsState> {
  ArchiveMonthsCubit({FirebaseFirestore? firestore, SharedPreferences? prefs})
    : _db = firestore ?? FirebaseFirestore.instance,
      _prefsFuture = prefs != null
          ? Future<SharedPreferences>.value(prefs)
          : SharedPreferences.getInstance(),
      super(ArchiveMonthsState.initial());

  final FirebaseFirestore _db;
  final Future<SharedPreferences> _prefsFuture;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _currentMonthSub;

  static const _cacheKey = 'archive_months_cache_v4';
  static const _cacheUpdatedKey = 'archive_months_cache_updated_at';
  static const _monthlyCollection = 'archive_months';
  static const String _emptyArchiveMessage = 'Archive is being built';

  Future<void> load({bool force = false}) async {
    emit(state.copyWith(loading: true, error: null));

    final cached = await _readCache();
    if (cached.isNotEmpty && !force) {
      final sorted = _sortMonths(cached);
      emit(
        state.copyWith(
          months: sorted,
          loading: false,
          fromCache: true,
          error: null,
          lastUpdated: await _readCacheUpdatedAt(),
        ),
      );
      _startCurrentMonthListener();
      unawaited(_fetchRemote(cached: cached, force: force));
      return;
    }

    await _fetchRemote(cached: cached, force: force);
  }

  Future<void> refresh() async {
    unawaited(syncMonthlyArchiveStats(force: true, backfillAllIfNeeded: true));
    await load(force: true);
  }

  Future<DateTime?> _readCacheUpdatedAt() async {
    final prefs = await _prefsFuture;
    final raw = prefs.getString(_cacheUpdatedKey);
    if (raw == null || raw.isEmpty) return null;
    return DateTime.tryParse(raw);
  }

  Future<List<ArchiveMonth>> _readCache() async {
    final prefs = await _prefsFuture;
    final raw = prefs.getString(_cacheKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final list = decoded
          .whereType<Map>()
          .map((m) => ArchiveMonth.fromCache(m.cast<String, dynamic>()))
          .toList();
      return _sortMonths(list);
    } catch (_) {
      return [];
    }
  }

  Future<void> _writeCache(List<ArchiveMonth> months) async {
    final prefs = await _prefsFuture;
    final payload = months.map((m) => m.toCache()).toList();
    await prefs.setString(_cacheKey, jsonEncode(payload));
    await prefs.setString(_cacheUpdatedKey, DateTime.now().toIso8601String());
  }

  Future<void> _fetchRemote({
    required List<ArchiveMonth> cached,
    required bool force,
  }) async {
    try {
      final cachedMap = {for (final m in cached) m.id: m};

      final monthlySnap = await _getQuerySnapshot(
        _db.collection(_monthlyCollection).orderBy(FieldPath.documentId),
        cacheFirst: !force,
      );
      if (monthlySnap.docs.isNotEmpty) {
        final months = monthlySnap.docs
            .map((doc) {
              final data = _normalizeMap(doc.data());
              return ArchiveMonth(id: doc.id, data: data);
            })
            .where((m) => m.data.isNotEmpty)
            .toList();
        if (months.isNotEmpty) {
          final merged = _mergeMonths(cachedMap, months);
          await _writeCache(merged);
          _startCurrentMonthListener();
          emit(
            state.copyWith(
              months: _sortMonths(merged),
              loading: false,
              fromCache: false,
              error: null,
              lastUpdated: DateTime.now(),
            ),
          );
          return;
        }
      }

      _startCurrentMonthListener();
      if (cachedMap.isNotEmpty) {
        emit(
          state.copyWith(
            months: _sortMonths(cachedMap.values.toList()),
            loading: false,
            fromCache: true,
            error: null,
          ),
        );
        return;
      }
      emit(
        state.copyWith(
          months: const [],
          loading: false,
          fromCache: false,
          error: _emptyArchiveMessage,
          lastUpdated: DateTime.now(),
        ),
      );
    } catch (e) {
      emit(state.copyWith(loading: false, error: e));
    }
  }

  List<ArchiveMonth> _mergeMonths(
    Map<String, ArchiveMonth> cached,
    List<ArchiveMonth> fresh,
  ) {
    final merged = Map<String, ArchiveMonth>.from(cached);
    for (final m in fresh) {
      merged[m.id] = m;
    }
    return _sortMonths(merged.values.toList());
  }

  String _monthKey(int year, int month) {
    final m = month.toString().padLeft(2, '0');
    return '$year-$m';
  }

  List<ArchiveMonth> _sortMonths(List<ArchiveMonth> input) {
    final list = List<ArchiveMonth>.from(input);
    list.sort((a, b) => b.id.compareTo(a.id));
    return list;
  }

  void _startCurrentMonthListener() {
    _currentMonthSub?.cancel();
    final now = DateTime.now();
    final key = _monthKey(now.year, now.month);
    _currentMonthSub = _db
        .collection(_monthlyCollection)
        .doc(key)
        .snapshots()
        .listen((snapshot) {
          final data = snapshot.data();
          if (data == null || data.isEmpty) return;
          final month = ArchiveMonth(
            id: snapshot.id,
            data: _normalizeMap(data),
          );
          final merged = _mergeMonths(
            {for (final m in state.months) m.id: m},
            [month],
          );
          emit(
            state.copyWith(
              months: _sortMonths(merged),
              loading: false,
              fromCache: false,
              error: state.error == _emptyArchiveMessage ? null : state.error,
              lastUpdated: DateTime.now(),
            ),
          );
        }, onError: (_) {});
  }

  void _stopCurrentMonthListener() {
    _currentMonthSub?.cancel();
    _currentMonthSub = null;
  }

  @override
  Future<void> close() {
    _stopCurrentMonthListener();
    return super.close();
  }
}

Map<String, dynamic> _normalizeMap(Map<String, dynamic> map) {
  final out = <String, dynamic>{};
  map.forEach((key, value) {
    out[key] = _normalizeValue(value);
  });
  return out;
}

dynamic _normalizeValue(dynamic value) {
  if (value == null) return null;
  if (value is Timestamp) {
    return value.toDate().toIso8601String();
  }
  if (value is DateTime) {
    return value.toIso8601String();
  }
  if (value is DocumentReference) {
    return value.path;
  }
  if (value is Map) {
    return _normalizeMap(value.cast<String, dynamic>());
  }
  if (value is List) {
    return value.map(_normalizeValue).toList();
  }
  if (value is num || value is String || value is bool) return value;
  return value.toString();
}

Future<QuerySnapshot<Map<String, dynamic>>> _getQuerySnapshot(
  Query<Map<String, dynamic>> query, {
  bool cacheFirst = false,
}) async {
  if (!cacheFirst) return query.get();
  try {
    final cached = await query.get(const GetOptions(source: Source.cache));
    if (cached.docs.isNotEmpty) return cached;
  } catch (_) {}
  return query.get();
}
