import 'package:cloud_firestore/cloud_firestore.dart';

Timestamp? normalizeToTimestamp(dynamic value) {
  if (value == null) return null;
  if (value is Timestamp) return value;
  if (value is DateTime) {
    return Timestamp.fromDate(value.isUtc ? value : value.toUtc());
  }
  if (value is int) {
    return Timestamp.fromMillisecondsSinceEpoch(value);
  }
  if (value is num) {
    return Timestamp.fromMillisecondsSinceEpoch(value.toInt());
  }
  if (value is String) {
    final parsed = DateTime.tryParse(value);
    if (parsed == null) return null;
    return Timestamp.fromDate(parsed.isUtc ? parsed : parsed.toUtc());
  }
  return null;
}
